rsync -avix --progress --exclude-from '.git' --exclude '*.pyc' ../KODI-Box/* repo/plugin.video.box

rsync -avix --progress --exclude-from '.git' ../KODI-OneDrive/* repo/plugin.video.onedrive

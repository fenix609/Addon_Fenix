rsync -avix --progress --exclude-from '.git' --exclude '*.pyc' ../KODI-MediaFire/* repo/plugin.video.mediafire

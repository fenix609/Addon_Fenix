rsync -avix --progress --exclude-from '.git' ../stable/GDrive-for-KODI/* repo/plugin.video.gdrive
#rsync -avix --progress --exclude-from '.git' ../XBMC-gdrive-0.3-dev/* repo.princeoliver/plugin.video.gdrive

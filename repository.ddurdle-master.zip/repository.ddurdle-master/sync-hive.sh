rsync -avix --progress --exclude-from '.git' --exclude '*.pyc' ../KODI-Hive/* repo/plugin.video.bitbase
